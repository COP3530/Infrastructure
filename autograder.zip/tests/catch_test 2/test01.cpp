#include "student_file.h"
#include "catch.hpp"


TEST_CASE( "Test 01", "Example Project" )
{
    //function from student_file.h
  Node* head = nullptr;                     //function from function.cpp
  head = insertEnd(head, 4);
  REQUIRE(interQuartile(head) == 4.0);    //function from student_file

}