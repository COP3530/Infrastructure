#include "student_file.h"

int main()
{
    int n;
    Node* head = nullptr;
    
    //creating the linked list from input
    while(std::cin >> n)
    {
        head = insertEnd(head, n);
    }
    
    std::cout << std::fixed << std::setprecision(2) << interQuartile(head);
    
    while (head != nullptr) 
    {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    
    return 0;
}